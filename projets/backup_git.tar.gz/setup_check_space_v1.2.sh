#!/bin/bash
# Script : setup_check_space.sh
# Version : 1.2
# Author : Antoine LEVY

VERSION=v1.2
BACKUP=/home/azureuser/backup_git

# Checks that the user has the root rights
if [ "$(id -u)" != "0" ]; then
        echo "Sorry, you are not root."
        exit 1
fi
# Creation of /home/azureuser/backup_git/scripts
if [ ! -d "$BACKUP/scripts" ]; then
        echo "Creation of directory : $BACKUP/scripts"
        mkdir $BACKUP/scripts
fi
if [ ! -d "$BACKUP/data" ]; then
        echo "Creation of directory : $BACKUP/data"
        mkdir $BACKUP/data
fi
if [ ! -d "$BACKUP/log" ]; then
        echo "Creation of directory : $BACKUP/log"
        mkdir $BACKUP/log
fi
# Create the file /root/backup_git/scripts/check_space.sh
if [ ! -f "$BACKUP/scripts/check_space_$VERSION.sh" ]; then
        echo "Creation of file : $BACKUP/scripts/check_space_$VERSION.sh"
        touch $BACKUP/scripts/check_space_$VERSION.sh
fi
sudo chmod +x $BACKUP/scripts/check_space_$VERSION.sh


# Write into the script /home/azureuser/backup_git/scripts/check_space.sh
# It will be called by cron
sudo echo -n "#!/bin/bash
# Script : check_space_$VERSION.sh
# Version : $VERSION
# Author : Antoine LEVY

echo \"check_space starting\"
# Creation of a temp file to store the available space on disk
touch /tmp/check_space.txt

# We write into /tmp/check_space.txt only th 4th column of the df -m BACKUP output
echo \"\$(df -m $BACKUP | awk '{print \$4}')\" > /tmp/check_space.txt

# We keep only the second line (the first line is the name of the column of the table created by df)
SPACE=\$(sed -n '2p' /tmp/check_space.txt)

# We erase the temp file no longer useful
rm /tmp/check_space.txt

if [ \$SPACE -lt 10000 ]; then
	logger -t backup_git_check-space WARNING : the current available space on the backup_git vm is less than 10Go, We suggest to free some space to avoid any further problems 
fi:q
if [ \$SPACE -lt 5000 ]; then
	logger -t backup_git_check-space ********* WARNING ********* : The available space on the backup_git vm is CRITIC !!!!!!! The available space is currently less than 5Go !!! You have to free some space !! 
fi

if [ \$SPACE -lt 2000 ]; then
	logger -t backup_git_check-space ********* WARNING ********* : The available space on the backup_git vm is CRITIC !!!!!!! The available space is currently less than 2Go !!! To free some space, the system is erasing the oldest backup 
	
	# Erasing the oldest backup to free some space
	for i in 1 2
	do 
		touch /tmp/select_erase.txt

		# We write into /tmp/select_erase.txt only th 9th column of the ls -l $BACKUP/data output representing the name
		echo \"\$(ls -l $BACKUP/data | awk '{print \$9}')\" > /tmp/select_erase.txt

		# We keep only the second line and third line to erase the oldest file (the first line is the name of the column of the table created by ls)
		VAR=\$(sed -n '2p' /tmp/select_erase.txt)

		# We erase the temp file no longer useful
		rm /tmp/select_erase.txt

		echo \"Erasing the file /tmp/\$VAR\"
		rm $BACKUP/data/\$VAR
	done
fi
echo \"check_space ending\"
exit 0;
" > $BACKUP/scripts/check_space_$VERSION.sh

sudo chown root:root $BACKUP/scripts/check_space_$VERSION.sh

# Configuration of CRON
echo "Configuration of crontab"

# First we make a copy of the current crontable 
sudo crontab -l > /tmp/my_crontab

# Then we add in the crontable the line that will execute : /home/azureuser/backup_git/scripts/check_space.sh
# that will be execute everyday at 6.00am UTC
# Note : Local Paris hour => Winter : 7.00am Summer => 8.00am
echo '* 6 * * * /home/azureuser/backup_git/scripts/check_space_$VERSION.sh' >> /tmp/my_crontab

# We replace the crontab
sudo crontab /tmp/my_crontab

# We erase the temporary crontab file
sudo rm -f /tmp/my_crontab

exit 0