#!/bin/bash
# Script : restore_backup_git.sh
# Version : 1.2
# Author : Antoine LEVY

# Checks that the user has the root rights
if [ "$(id -u)" != "0" ]; then
	    echo "Sorry, you are not root."
	    exit 101
fi

# Checks script arguments
if [ $# -lt 1 ]; then
		echo "Usage: $0 <date of backup file>"
		echo "Format :'%Y%m%d-%H%M%S'"
		exit 102
fi

BACKUP=/home/azureuser/backup_git
BACKUPNAME=$1_backup_git.tar.gz

echo "Restoration_backup_script starting"

# Change to the directory containing your backup.
if [ -r "$BACKUP/data" ]; then
    	cd /home/azureuser/backup_git/data
else
	    echo "Sorry cannot find $BACKUP/data directory"
	    echo "Please check your backup file exist and is in directory /home/azureuser/backup_git/data"
	    exit 103
fi

# Search for the backup file to restore
if [ ! -f "$BACKUP/data/$BACKUPNAME" ]; then
        echo "Error : cannot find the backup file '$BACKUP/data/$BACKUPNAME'"
        echo "Check the spelling and the emplacement of your backup file please"
        echo "The date's format must be : '%Y%m%d-%H%M%S'"
        exit 104
fi

# Stop all servers.
sudo /opt/bitnami/ctlscript.sh stop

# Rename the current directory to save it.
sudo mv /opt/bitnami /opt/bitnamiBackup

# Uncompress the backup file to the original directory.
sudo tar -pxzvf $BACKUP/data/$BACKUPNAME -C /

# Start all servers.
sudo /opt/bitnami/ctlscript.sh start

echo "*************************************************************************************************"
echo "**********Don't forget to modify the hostname ip address in /opt/bitnami/properties.ini**********"
echo "*************************************************************************************************"

echo "Restoration_backup-script ending"

exit 0