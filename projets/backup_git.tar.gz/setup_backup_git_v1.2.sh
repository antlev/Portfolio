#!/bin/bash
# Script : setup_backup_git.sh
# Version : 1.2
# Author : Antoine LEVY

echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - Preparing the installation of the automatic backup system" >> $BACKUP/log/backup_git.log

VERSION=v1.2
MYUSER=root
BACKUP=/$MYUSER/backup_git
BACKUP_SCRIPT=$BACKUP/scripts

# CHANGE THE STORAGE SERVER IP IF IT IS NECESSARY
IP=10.0.0.44 # IP of the GitLab_Backup vm

# Checks that the user has the root rights
if [ "$(id -u)" != "0" ]; then
        echo "Sorry, you are not root."
        exit 1
fi
# Create the necessary directories if they don't exist 
# Creation of /root/backup_git
if [ ! -d "$BACKUP" ]; then
        echo "Creation of directory : $BACKUP"
        mkdir $BACKUP
fi
# Creation of /root/backup_git/log
if [ ! -d "$BACKUP/log" ]; then
        echo "Creation of directory : $BACKUP/log" 
        mkdir $BACKUP/log
fi
if [ ! -f "$BACKUP/log/backup_git.log" ]; then
        touch $BACKUP/log/backup_git.log
        echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - Creation of file : $BACKUP/log/backup_git.log"  
fi
# Creation of /root/backup_git/data
if [ ! -d "$BACKUP/data" ]; then
        echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - Creation of directory : $BACKUP/data" >> $BACKUP/log/backup_git.log
        mkdir $BACKUP/data
fi
# Creation of /root/backup_git/scripts
if [ ! -d "$BACKUP_SCRIPT" ]; then
        echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - Creation of directory : $BACKUP_SCRIPT" >> $BACKUP/log/backup_git.log
        mkdir $BACKUP_SCRIPT
fi
# Create the file /root/backup_git/scripts/backup_git.sh
if [ ! -f "$BACKUP_SCRIPT/backup_git_$VERSION.sh" ]; then
        echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh -Creation of file : $BACKUP_SCRIPT/backup_git_$VERSION.sh" >> $BACKUP/log/backup_git.log 
        touch $BACKUP_SCRIPT/backup_git_$VERSION.sh
        chmod +x $BACKUP_SCRIPT/backup_git_$VERSION.sh
fi

# Write into the script /root/backup_git/scripts/backup_git.sh
# It will be called by cron
sudo echo -n "#!/bin/bash
# Script : backup_git_$VERSION.sh
# Version : $VERSION
# Author : Antoine LEVY

echo \"Backup_script starting\"
# Checks that the user has the root rights
if [ \"$(id -u)\" != \"0\" ]; then
        echo \"Sorry, you are not root.\"
        echo \" - backup_git.sh - Someone tried to launch the script backup_git_$VERSION.sh without the root rights\" >> $BACKUP/log/backup_git.log 
        exit 1
fi
# Create the necessary directories if they don't exist 
if [ ! -d \"$BACKUP\" ]; then
        echo \"\`date +%Y%m%d-%H%M%S\`- backup_git.sh - Creation of directory : $BACKUP\"  >> $BACKUP/log/backup_git.log
        mkdir $BACKUP
fi
if [ ! -d \"$BACKUP/data\" ]; then
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Creation of directory : $BACKUP/data\"  >> $BACKUP/log/backup_git.log
        mkdir $BACKUP/data
fi
if [ ! -d \"$BACKUP/log\" ]; then
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Creation of directory : $BACKUP/log\"  >> $BACKUP/log/backup_git.log
        mkdir $BACKUP/log
fi
if [ ! -f \"$BACKUP/log/backup_git.log\" ]; then
        touch $BACKUP/log/backup_git.log
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Creation of file : $BACKUP/log/backup_git.log\" >> $BACKUP/log/backup_git.log
fi
if [ ! -d \"$BACKUP_SCRIPT\" ]; then
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Creation of directory : $BACKUP_SCRIPT\" >> $BACKUP/log/backup_git.log
        mkdir $BACKUP_SCRIPT
fi
if [ ! -f \"$BACKUP_SCRIPT/backup_git_$VERSION.sh\" ]; then
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Creation of file : $BACKUP_SCRIPT/backup_git_$VERSION.sh\" >> $BACKUP/log/backup_git.log
        touch $BACKUP_SCRIPT/backup_git_$VERSION.sh
        chmod +x $BACKUP_SCRIPT/backup_git_$VERSION.sh
fi

# We stop all servers
/opt/bitnami/ctlscript.sh stop
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - services stop\" >> $BACKUP/log/backup_git.log

# stock a variable containing the date and time of the backup
SHANAME=\`date +%Y%m%d-%H%M%S\`_backup_git.txt
BACKUPNAME=\`date +%Y%m%d-%H%M%S\`_backup_git.tar.gz

# Create a compressed file with the stack contents.
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - tar starting\" >> $BACKUP/log/backup_git.log
tar -pczvf $BACKUP/data/\$BACKUPNAME /opt/bitnami
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - tar finished\" >> $BACKUP/log/backup_git.log

# Restart all servers.
/opt/bitnami/ctlscript.sh start
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - services start\" >> $BACKUP/log/backup_git.log

echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Backup file is located at : $BACKUP/data/\$BACKUPNAME\" >> $BACKUP/log/backup_git.log

# Copy the file on an other vm
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - scp starting\" >> $BACKUP/log/backup_git.log
scp $BACKUP/data/\$BACKUPNAME azureuser@$IP:/home/azureuser/backup_git/data
echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - scp finished\" >> $BACKUP/log/backup_git.log


# Recovering of the local backup file fingerprint
DEPARTURE=\$(sha256sum /root/backup_git/data/\$BACKUPNAME | head -c 64)

# Recovering of the distant backup file fingerprint
ARRIVAL=\$(ssh azureuser@$IP sha256sum /home/azureuser/backup_git/data/\$BACKUPNAME | head -c 64)

# Comparaison between both fingerptints to check the integrity of the copy
if [ \$DEPARTURE = \$ARRIVAL ]; then
	# If the fingerprints are the same, we can erase the local backup
        echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - sha256sum comparaison success\" >> $BACKUP/log/backup_git.log
	echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Suppression of $BACKUP/data/\$BACKUPNAME\" >> $BACKUP/log/backup_git.log
	rm $BACKUP/data/\$BACKUPNAME
	# And generate a sha of the sended file to guarantee the integrity of the backup file and to permit to use it for further actions
	ssh azureuser@$IP touch /home/azureuser/backup_git/data/\$SHANAME
	ssh azureuser@$IP sha256sum /home/azureuser/backup_git/data/\$BACKUPNAME > /home/azureuser/backup_git/data/\$SHANAME
else
	echo \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Error scp : There has been an error during the files's copy,the copied file isn't integrate\" >> $BACKUP/log/backup_git.log

	# Writing into the local backup log file
	echo -n \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Error #: The sha fingerprint of the departure file and the arrival file are different\" >> $BACKUP/log/backup_git.log
        echo -n \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Error : the copied file isn't integrate\" >> $BACKUP/log/backup_git.log
        echo -n \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Be careful : the backup file /home/azureuser/backup_git/data/\$BACKUPNAME that is on the virtual machine that stores the backup files is very probably not integer !\" >> $BACKUP/log/backup_git.log
        echo -n \"\`date +%Y%m%d-%H%M%S\` - backup_git.sh - Therefor the file $BACKUP/data/\$BACKUPNAME on GitLab hasn't been deleted to preserve the backup\" >> $BACKUP/log/backup_git.log

	# Writing into the syslog to pass on the alert to us
	logger -t backup_git_error The copied file isn\'t integrate
	logger -t backup_git_error The sha fingerprint of the departure file and the arrival file seem to be different
	logger -t backup_git_error Be careful : the backup file /home/azureuser/backup_git/data/\$BACKUPNAME that is on the virtual machine that stores the backup files is very probably not integer !
	logger -t backup_git_error Therefor the file $BACKUP/data/\$BACKUPNAME on GitLab hasn\'t been deleted to preserve the backup
fi

echo \"Backup-script ending\"
exit 0
" > $BACKUP_SCRIPT/backup_git_$VERSION.sh

chown $MYUSER:$MYUSER $BACKUP_SCRIPT/backup_git_$VERSION.sh

# Configuration of CRON
echo "Configuration of crontab"

# First we make a copy of the current crontable 
sudo crontab -l > /tmp/my_crontab

# Then we add in the crontable the line that will execute : /root/backup_git/scripts/backup_git.sh
# that will be execute everyday at 3.00am UTC
# Note : Local Paris hour => Winter : 4.00am Summer => 5.00am
echo '0 3 * * * /root/backup_git/scripts/backup_git_$VERSION.sh' >> /tmp/my_crontab

# We replace the crontab
sudo crontab /tmp/my_crontab
echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - crontable has been updated" >> $BACKUP/log/backup_git.log


# We erase the temporary crontab file
sudo rm -f /tmp/my_crontab


# Configuration of SSH to access the storage backup vm without using a password but an ssh key
echo "Configuration of the ssh keys"

apt-get -y install openssh-client

# -f indicate the file // -N force to enter the default values
sudo ssh-keygen -t rsa -f /root/.ssh/id_rsa -N ''
echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - ssh key generated" >> $BACKUP/log/backup_git.log

# Copy of the ssh keys on the storage backup vm 
sudo ssh-copy-id -i /root/.ssh/id_rsa azureuser@$IP
echo "`date +%Y%m%d-%H%M%S`- setup_backup_git.sh - ssh key were sent to azureuser@$IP" >> $BACKUP/log/backup_git.log

echo "`date +%Y%m%d-%H%M%S` - setup_backup_git.sh - End of backup preparation script" >> $BACKUP/log/backup_git.log

exit 0
# command to execute on the vm that will store the backups
# sudo apt-get install openssh-server


